#!/bin/bash
mostrar_ayuda() {
  echo "Uso: $0 <origen> <destino>"
  echo ""
  echo "Este script genera un backup comprimido (.tar.gz) del directorio <origen>"
  echo "y lo guarda en <destino> con un nombre que incluye la fecha en formata YYYYMMDD."
  echo ""
  echo "Ejemplo"
  echo " %0 /var/logs /backup_dir"
  echo ""
  echo "Opciones:"
  echo " -help   muestra esta ayuda"
  exit 0
}

if [ "$1" == "-help" ]; then
  mostrar_ayuda
fi

if [ $# -ne 2]; then
  echo "Error: cantidad incorrecta de argumentos."
  echo "Usà -help para mas informacion."
  exit 1
fi

ORIGEN=$1
DESTINO=$2

if [ ! -d "$ORIGEN" ]; then
  echo "Error: el directorio de origen '$ORIGEN' no existe."
  exit 2
fi

if [ ! -d "$DESTINO" ]; then
  echo "Error: el directorio de destino '$DESTINO' no existe."
  exit 3
fi

if ! mountpoint -q "$ORIGEN"; then
  echo "Error: el punto de montaje del origen '$ORIGEN' no esta disponible."
  exit 4
fi

if ! mountpoint -q "$DESTINO"; then
  echo "Error: el punto de montaje del destino '$DESTINO' no esta disponible"
  exit 5
fi

NOMBRE=$(basename "$ORIGEN")

FECHA=$(date +%Y%m%d)

tar -czf "$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz" "$ORIGEN"

echo "backup de $ORIGEN generado en $DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"
